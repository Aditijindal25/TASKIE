import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../hooks/useTasks';
import TaskItem from '../components/TaskItem';
import styles from './Dashboard.module.css';

const FILTERS = ['All', 'To Do', 'Done', 'High Priority'];
const TAG_OPTIONS = ['fe', 'be', 'db'];
const PRIORITY_OPTIONS = ['high', 'med', 'low'];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { tasks, loading, addTask, updateTask, deleteTask, toggleTask } = useTasks();
  const [filter, setFilter] = useState('All');
  const [newTaskName, setNewTaskName] = useState('');
  const [newTag, setNewTag] = useState('fe');
  const [newPriority, setNewPriority] = useState('med');

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'To Do') return !t.done;
    if (filter === 'Done') return t.done;
    if (filter === 'High Priority') return t.priority === 'high';
    return true;
  });

  const stats = {
    total: tasks.length,
    done: tasks.filter((t) => t.done).length,
    inProgress: tasks.filter((t) => !t.done).length,
    pct: tasks.length ? Math.round((tasks.filter((t) => t.done).length / tasks.length) * 100) : 0,
  };

  const handleAdd = async (e) => {
    if (e.key === 'Enter' && newTaskName.trim()) {
      await addTask({ name: newTaskName.trim(), tag: newTag, priority: newPriority });
      setNewTaskName('');
    }
  };

  const initials = user?.name?.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2) || 'U';

  return (
    <div className={styles.layout}>
      <aside className={styles.sidebar}>
        <div className={styles.logo}>
          <div className={styles.logoMark}>t</div>
          <span className={styles.logoName}>ta<em>skie</em></span>
        </div>
        <nav className={styles.nav}>
          <span className={styles.navSection}>Workspace</span>
          <div className={`${styles.navItem} ${styles.active}`}>📋 My Tasks</div>
          <div className={styles.navItem}>📁 Projects</div>
          <div className={styles.navItem}>👥 Team</div>
          <span className={styles.navSection}>Insights</span>
          <div className={styles.navItem}>📊 Analytics</div>
          <div className={styles.navItem}>⚙️ Settings</div>
        </nav>
        <div className={styles.sidebarBottom}>
          <div className={styles.userRow}>
            <div className={styles.avatar}>{initials}</div>
            <div>
              <div className={styles.userName}>{user?.name}</div>
              <button className={styles.logoutBtn} onClick={logout}>Sign out</button>
            </div>
          </div>
        </div>
      </aside>

      <main className={styles.main}>
        <div className={styles.topbar}>
          <span className={styles.pageTitle}>My Tasks</span>
          <div className={styles.topbarRight}>
            <span className={styles.greeting}>Hello, {user?.name?.split(' ')[0]} 👋</span>
          </div>
        </div>

        <div className={styles.content}>
          <div className={styles.statsRow}>
            <div className={styles.statCard}>
              <div className={styles.statLabel}>Total Tasks</div>
              <div className={styles.statValue}>{stats.total}</div>
            </div>
            <div className={styles.statCard}>
              <div className={styles.statLabel}>Completed</div>
              <div className={styles.statValue}>{stats.done}</div>
            </div>
            <div className={styles.statCard}>
              <div className={styles.statLabel}>In Progress</div>
              <div className={styles.statValue}>{stats.inProgress}</div>
            </div>
            <div className={styles.statCard}>
              <div className={styles.statLabel}>Completion</div>
              <div className={styles.statValue}>{stats.pct}%</div>
              <div className={styles.progressBar}>
                <div className={styles.progressFill} style={{ width: `${stats.pct}%` }} />
              </div>
            </div>
          </div>

          <div className={styles.tasksHeader}>
            <span className={styles.tasksTitle}>Tasks</span>
            <div className={styles.filterRow}>
              {FILTERS.map((f) => (
                <button
                  key={f}
                  className={`${styles.chip} ${filter === f ? styles.active : ''}`}
                  onClick={() => setFilter(f)}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className={styles.loading}>Loading tasks...</div>
          ) : (
            <div className={styles.taskList}>
              {filteredTasks.length === 0 && (
                <div className={styles.empty}>No tasks here. Add one below!</div>
              )}
              {filteredTasks.map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  onToggle={() => toggleTask(task.id)}
                  onDelete={() => deleteTask(task.id)}
                  onUpdate={(updates) => updateTask(task.id, updates)}
                />
              ))}
            </div>
          )}

          <div className={styles.addRow}>
            <div className={styles.addSelects}>
              <select value={newTag} onChange={(e) => setNewTag(e.target.value)} className={styles.select}>
                {TAG_OPTIONS.map((t) => <option key={t} value={t}>{t.toUpperCase()}</option>)}
              </select>
              <select value={newPriority} onChange={(e) => setNewPriority(e.target.value)} className={styles.select}>
                {PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
              </select>
            </div>
            <input
              className={styles.addInput}
              value={newTaskName}
              onChange={(e) => setNewTaskName(e.target.value)}
              onKeyDown={handleAdd}
              placeholder="＋  Add a task and press Enter..."
              maxLength={100}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
