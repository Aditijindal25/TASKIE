import styles from './TaskItem.module.css';

const TAG_LABELS = { fe: 'Frontend', be: 'Backend', db: 'Database' };

export default function TaskItem({ task, onToggle, onDelete }) {
  const date = task.due_date
    ? new Date(task.due_date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })
    : task.created_at
    ? new Date(task.created_at).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })
    : '';

  return (
    <div className={`${styles.item} ${task.done ? styles.done : ''}`}>
      <div
        className={`${styles.check} ${task.done ? styles.checked : ''}`}
        onClick={onToggle}
        role="checkbox"
        aria-checked={task.done}
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && onToggle()}
      >
        {task.done && '✓'}
      </div>
      <div className={styles.body}>
        <div className={styles.name}>{task.name}</div>
        <div className={styles.meta}>
          <span className={`${styles.tag} ${styles[task.tag]}`}>{TAG_LABELS[task.tag] || task.tag}</span>
          {date && <span className={styles.date}>{date}</span>}
        </div>
      </div>
      <div className={`${styles.priority} ${styles[`p_${task.priority}`]}`} title={`${task.priority} priority`} />
      <button className={styles.deleteBtn} onClick={onDelete} aria-label="Delete task">✕</button>
    </div>
  );
}
